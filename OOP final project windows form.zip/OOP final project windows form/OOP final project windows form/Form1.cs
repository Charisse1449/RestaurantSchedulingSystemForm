﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OOP_final_project_windows_form
{
    public partial class Appointment : Form
    {
        public Appointment()
        {
            InitializeComponent();
        }

        private async void Form1_Load(object sender, EventArgs e)
        {
            ApiService apiService = new ApiService();
            var appointments = await apiService.GetAppointmentsAsync();
            foreach (var appointment in appointments)
            {
                // Assuming you have a ListBox called listBoxAppointments
                listBoxAppointments.Items.Add($"{appointment.Id}: {appointment.CustomerName} at {appointment.AppointmentDate}");
            }
        }

        private async void btnCreateAppointment_Click(object sender, EventArgs e)
        {
            var appointment = new Appointment
            {
                CustomerName = txtCustomerName.Text,
                AppointmentDate = dateTimePickerAppointment.Value,
                NumberOfPeople = int.Parse(txtNumPeople.Text),
                Status = "Scheduled"
            };

            ApiService apiService = new ApiService();
            await apiService.CreateAppointmentAsync(appointment);

            MessageBox.Show("Appointment Created Successfully!");

        }
    }
}
