﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Headers;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace OOP_final_project_windows_form
{
    public class ApiService
    {
        private readonly HttpClient _client;

        public ApiService()
        {
            _client = new HttpClient();
            _client.BaseAddress = new Uri("https://localhost:5001/api/");  // URL of your Web API
            _client.DefaultRequestHeaders.Accept.Clear();
            _client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
        }

        public async Task<Appointment[]> GetAppointmentsAsync()
        {
            HttpResponseMessage response = await _client.GetAsync("appointments");
            response.EnsureSuccessStatusCode();

            var responseBody = await response.Content.ReadAsStringAsync();
            var appointments = JsonSerializer.Deserialize<Appointment[]>(responseBody);
            return appointments;
        }

        public async Task CreateAppointmentAsync(Appointment appointment)
        {
            var content = new StringContent(JsonSerializer.Serialize(appointment), System.Text.Encoding.UTF8, "application/json");
            HttpResponseMessage response = await _client.PostAsync("appointments", content);
            response.EnsureSuccessStatusCode();
        }
    }
}
